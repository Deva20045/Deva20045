import { 
  facilities, 
  timeSlots, 
  bookings, 
  users, 
  type User, 
  type InsertUser,
  type Facility,
  type InsertFacility,
  type TimeSlot,
  type InsertTimeSlot,
  type Booking,
  type InsertBooking,
  type BookingWithDetails,
  type TimeSlotWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Facility operations
  getFacilities(): Promise<Facility[]>;
  getFacility(id: number): Promise<Facility | undefined>;
  createFacility(facility: InsertFacility): Promise<Facility>;
  updateFacility(id: number, facility: Partial<InsertFacility>): Promise<Facility | undefined>;

  // Time slot operations
  getTimeSlotsByFacilityAndDate(facilityId: number, date: string): Promise<TimeSlotWithDetails[]>;
  getTimeSlot(id: number): Promise<TimeSlot | undefined>;
  createTimeSlot(timeSlot: InsertTimeSlot): Promise<TimeSlot>;
  updateTimeSlotAvailability(id: number, isAvailable: boolean): Promise<TimeSlot | undefined>;
  getAvailableTimeSlots(date: string): Promise<TimeSlotWithDetails[]>;

  // Booking operations
  getBookings(): Promise<BookingWithDetails[]>;
  getBooking(id: number): Promise<BookingWithDetails | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  getBookingsByEmail(email: string): Promise<BookingWithDetails[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, role: "user" })
      .returning();
    return user;
  }

  async getFacilities(): Promise<Facility[]> {
    return await db.select().from(facilities).where(eq(facilities.isActive, true));
  }

  async getFacility(id: number): Promise<Facility | undefined> {
    const [facility] = await db.select().from(facilities).where(eq(facilities.id, id));
    return facility || undefined;
  }

  async createFacility(facility: InsertFacility): Promise<Facility> {
    const [newFacility] = await db
      .insert(facilities)
      .values(facility)
      .returning();
    return newFacility;
  }

  async updateFacility(id: number, facility: Partial<InsertFacility>): Promise<Facility | undefined> {
    const [updated] = await db
      .update(facilities)
      .set(facility)
      .where(eq(facilities.id, id))
      .returning();
    return updated || undefined;
  }

  async getTimeSlotsByFacilityAndDate(facilityId: number, date: string): Promise<TimeSlotWithDetails[]> {
    const slots = await db
      .select({
        id: timeSlots.id,
        facilityId: timeSlots.facilityId,
        date: timeSlots.date,
        startTime: timeSlots.startTime,
        endTime: timeSlots.endTime,
        isAvailable: timeSlots.isAvailable,
        priceOverride: timeSlots.priceOverride,
        facilityName: facilities.name,
        pricePerHour: timeSlots.priceOverride,
      })
      .from(timeSlots)
      .leftJoin(facilities, eq(timeSlots.facilityId, facilities.id))
      .where(and(eq(timeSlots.facilityId, facilityId), eq(timeSlots.date, date)))
      .orderBy(timeSlots.startTime);

    return slots.map(slot => ({
      ...slot,
      facilityName: slot.facilityName || "Unknown",
      pricePerHour: slot.priceOverride || "600.00"
    }));
  }

  async getTimeSlot(id: number): Promise<TimeSlot | undefined> {
    const [timeSlot] = await db.select().from(timeSlots).where(eq(timeSlots.id, id));
    return timeSlot || undefined;
  }

  async createTimeSlot(timeSlot: InsertTimeSlot): Promise<TimeSlot> {
    const [newTimeSlot] = await db
      .insert(timeSlots)
      .values(timeSlot)
      .returning();
    return newTimeSlot;
  }

  async updateTimeSlotAvailability(id: number, isAvailable: boolean): Promise<TimeSlot | undefined> {
    const [updated] = await db
      .update(timeSlots)
      .set({ isAvailable })
      .where(eq(timeSlots.id, id))
      .returning();
    return updated || undefined;
  }

  async getAvailableTimeSlots(date: string): Promise<TimeSlotWithDetails[]> {
    const slots = await db
      .select({
        id: timeSlots.id,
        facilityId: timeSlots.facilityId,
        date: timeSlots.date,
        startTime: timeSlots.startTime,
        endTime: timeSlots.endTime,
        isAvailable: timeSlots.isAvailable,
        priceOverride: timeSlots.priceOverride,
        facilityName: facilities.name,
        pricePerHour: facilities.pricePerHour,
      })
      .from(timeSlots)
      .leftJoin(facilities, eq(timeSlots.facilityId, facilities.id))
      .where(and(eq(timeSlots.date, date), eq(timeSlots.isAvailable, true)))
      .orderBy(timeSlots.facilityId, timeSlots.startTime);

    return slots.map(slot => ({
      ...slot,
      facilityName: slot.facilityName || "Unknown",
      pricePerHour: slot.priceOverride || slot.pricePerHour || "600.00"
    }));
  }

  async getBookings(): Promise<BookingWithDetails[]> {
    const bookingsList = await db
      .select({
        id: bookings.id,
        facilityId: bookings.facilityId,
        timeSlotId: bookings.timeSlotId,
        customerName: bookings.customerName,
        customerEmail: bookings.customerEmail,
        customerPhone: bookings.customerPhone,
        numberOfPlayers: bookings.numberOfPlayers,
        specialRequests: bookings.specialRequests,
        totalAmount: bookings.totalAmount,
        paymentStatus: bookings.paymentStatus,
        bookingStatus: bookings.bookingStatus,
        createdAt: bookings.createdAt,
        facilityName: facilities.name,
        date: timeSlots.date,
        startTime: timeSlots.startTime,
        endTime: timeSlots.endTime,
      })
      .from(bookings)
      .leftJoin(facilities, eq(bookings.facilityId, facilities.id))
      .leftJoin(timeSlots, eq(bookings.timeSlotId, timeSlots.id))
      .orderBy(bookings.createdAt);

    return bookingsList.map(booking => ({
      ...booking,
      facilityName: booking.facilityName || "Unknown",
      date: booking.date || "",
      startTime: booking.startTime || "",
      endTime: booking.endTime || ""
    }));
  }

  async getBooking(id: number): Promise<BookingWithDetails | undefined> {
    const [booking] = await db
      .select({
        id: bookings.id,
        facilityId: bookings.facilityId,
        timeSlotId: bookings.timeSlotId,
        customerName: bookings.customerName,
        customerEmail: bookings.customerEmail,
        customerPhone: bookings.customerPhone,
        numberOfPlayers: bookings.numberOfPlayers,
        specialRequests: bookings.specialRequests,
        totalAmount: bookings.totalAmount,
        paymentStatus: bookings.paymentStatus,
        bookingStatus: bookings.bookingStatus,
        createdAt: bookings.createdAt,
        facilityName: facilities.name,
        date: timeSlots.date,
        startTime: timeSlots.startTime,
        endTime: timeSlots.endTime,
      })
      .from(bookings)
      .leftJoin(facilities, eq(bookings.facilityId, facilities.id))
      .leftJoin(timeSlots, eq(bookings.timeSlotId, timeSlots.id))
      .where(eq(bookings.id, id));

    if (!booking) return undefined;

    return {
      ...booking,
      facilityName: booking.facilityName || "Unknown",
      date: booking.date || "",
      startTime: booking.startTime || "",
      endTime: booking.endTime || ""
    };
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db
      .insert(bookings)
      .values(booking)
      .returning();
    
    // Mark time slot as unavailable
    await this.updateTimeSlotAvailability(booking.timeSlotId, false);
    
    return newBooking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    if (!booking) return undefined;

    const [updated] = await db
      .update(bookings)
      .set({ bookingStatus: status })
      .where(eq(bookings.id, id))
      .returning();
    
    // If booking is cancelled, make the time slot available again
    if (status === "cancelled") {
      await this.updateTimeSlotAvailability(booking.timeSlotId, true);
    }
    
    return updated || undefined;
  }

  async getBookingsByEmail(email: string): Promise<BookingWithDetails[]> {
    const bookingsList = await db
      .select({
        id: bookings.id,
        facilityId: bookings.facilityId,
        timeSlotId: bookings.timeSlotId,
        customerName: bookings.customerName,
        customerEmail: bookings.customerEmail,
        customerPhone: bookings.customerPhone,
        numberOfPlayers: bookings.numberOfPlayers,
        specialRequests: bookings.specialRequests,
        totalAmount: bookings.totalAmount,
        paymentStatus: bookings.paymentStatus,
        bookingStatus: bookings.bookingStatus,
        createdAt: bookings.createdAt,
        facilityName: facilities.name,
        date: timeSlots.date,
        startTime: timeSlots.startTime,
        endTime: timeSlots.endTime,
      })
      .from(bookings)
      .leftJoin(facilities, eq(bookings.facilityId, facilities.id))
      .leftJoin(timeSlots, eq(bookings.timeSlotId, timeSlots.id))
      .where(eq(bookings.customerEmail, email))
      .orderBy(bookings.createdAt);

    return bookingsList.map(booking => ({
      ...booking,
      facilityName: booking.facilityName || "Unknown",
      date: booking.date || "",
      startTime: booking.startTime || "",
      endTime: booking.endTime || ""
    }));
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private facilities: Map<number, Facility>;
  private timeSlots: Map<number, TimeSlot>;
  private bookings: Map<number, Booking>;
  private currentUserId: number;
  private currentFacilityId: number;
  private currentTimeSlotId: number;
  private currentBookingId: number;

  constructor() {
    this.users = new Map();
    this.facilities = new Map();
    this.timeSlots = new Map();
    this.bookings = new Map();
    this.currentUserId = 1;
    this.currentFacilityId = 1;
    this.currentTimeSlotId = 1;
    this.currentBookingId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Create sample facilities
    const facility1: Facility = {
      id: this.currentFacilityId++,
      name: "TurfCourt Premium",
      type: "premium",
      description: "Professional-grade artificial turf for premium sports experience",
      pricePerHour: "600.00",
      imageUrl: "https://images.unsplash.com/photo-1459865264687-595d652de67e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=320",
      isActive: true
    };

    const facility2: Facility = {
      id: this.currentFacilityId++,
      name: "TurfCourt Standard",
      type: "standard",
      description: "High-quality artificial turf for regular sports activities",
      pricePerHour: "600.00",
      imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=320",
      isActive: true
    };

    this.facilities.set(facility1.id, facility1);
    this.facilities.set(facility2.id, facility2);

    // Create time slots for today and tomorrow
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const timeSlotTimes = [
      { start: "06:00", end: "07:00" },
      { start: "07:00", end: "08:00" },
      { start: "08:00", end: "09:00" },
      { start: "09:00", end: "10:00" },
      { start: "10:00", end: "11:00" },
      { start: "11:00", end: "12:00" },
      { start: "12:00", end: "13:00" },
      { start: "13:00", end: "14:00" },
      { start: "14:00", end: "15:00" },
      { start: "15:00", end: "16:00" },
      { start: "16:00", end: "17:00" },
      { start: "17:00", end: "18:00" },
      { start: "18:00", end: "19:00" },
      { start: "19:00", end: "20:00" },
      { start: "20:00", end: "21:00" },
      { start: "21:00", end: "22:00" },
      { start: "22:00", end: "23:00" },
      { start: "23:00", end: "00:00" }
    ];

    [today, tomorrow].forEach(date => {
      const dateStr = date.toISOString().split('T')[0];
      [facility1, facility2].forEach(facility => {
        timeSlotTimes.forEach(time => {
          const timeSlot: TimeSlot = {
            id: this.currentTimeSlotId++,
            facilityId: facility.id,
            date: dateStr,
            startTime: time.start,
            endTime: time.end,
            isAvailable: Math.random() > 0.3, // 70% availability
            priceOverride: null
          };
          this.timeSlots.set(timeSlot.id, timeSlot);
        });
      });
    });

    // Create admin user
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      password: "admin123",
      role: "admin"
    };
    this.users.set(adminUser.id, adminUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, role: "user" };
    this.users.set(id, user);
    return user;
  }

  async getFacilities(): Promise<Facility[]> {
    return Array.from(this.facilities.values()).filter(f => f.isActive);
  }

  async getFacility(id: number): Promise<Facility | undefined> {
    return this.facilities.get(id);
  }

  async createFacility(facility: InsertFacility): Promise<Facility> {
    const id = this.currentFacilityId++;
    const newFacility: Facility = { 
      ...facility, 
      id,
      imageUrl: facility.imageUrl || null,
      isActive: facility.isActive ?? true
    };
    this.facilities.set(id, newFacility);
    return newFacility;
  }

  async updateFacility(id: number, facility: Partial<InsertFacility>): Promise<Facility | undefined> {
    const existing = this.facilities.get(id);
    if (!existing) return undefined;
    
    const updated: Facility = { ...existing, ...facility };
    this.facilities.set(id, updated);
    return updated;
  }

  async getTimeSlotsByFacilityAndDate(facilityId: number, date: string): Promise<TimeSlotWithDetails[]> {
    const facility = this.facilities.get(facilityId);
    if (!facility) return [];

    const slots = Array.from(this.timeSlots.values())
      .filter(slot => slot.facilityId === facilityId && slot.date === date)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

    return slots.map(slot => ({
      ...slot,
      facilityName: facility.name,
      pricePerHour: slot.priceOverride || facility.pricePerHour
    }));
  }

  async getTimeSlot(id: number): Promise<TimeSlot | undefined> {
    return this.timeSlots.get(id);
  }

  async createTimeSlot(timeSlot: InsertTimeSlot): Promise<TimeSlot> {
    const id = this.currentTimeSlotId++;
    const newTimeSlot: TimeSlot = { 
      ...timeSlot, 
      id,
      isAvailable: timeSlot.isAvailable ?? true,
      priceOverride: timeSlot.priceOverride || null
    };
    this.timeSlots.set(id, newTimeSlot);
    return newTimeSlot;
  }

  async updateTimeSlotAvailability(id: number, isAvailable: boolean): Promise<TimeSlot | undefined> {
    const timeSlot = this.timeSlots.get(id);
    if (!timeSlot) return undefined;

    const updated: TimeSlot = { ...timeSlot, isAvailable };
    this.timeSlots.set(id, updated);
    return updated;
  }

  async getAvailableTimeSlots(date: string): Promise<TimeSlotWithDetails[]> {
    const slots = Array.from(this.timeSlots.values())
      .filter(slot => slot.date === date && slot.isAvailable)
      .sort((a, b) => a.facilityId - b.facilityId || a.startTime.localeCompare(b.startTime));

    return slots.map(slot => {
      const facility = this.facilities.get(slot.facilityId);
      return {
        ...slot,
        facilityName: facility?.name || "Unknown",
        pricePerHour: slot.priceOverride || facility?.pricePerHour || "0.00"
      };
    });
  }

  async getBookings(): Promise<BookingWithDetails[]> {
    const bookings = Array.from(this.bookings.values())
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    return bookings.map(booking => {
      const facility = this.facilities.get(booking.facilityId);
      const timeSlot = this.timeSlots.get(booking.timeSlotId);
      return {
        ...booking,
        facilityName: facility?.name || "Unknown",
        date: timeSlot?.date || "",
        startTime: timeSlot?.startTime || "",
        endTime: timeSlot?.endTime || ""
      };
    });
  }

  async getBooking(id: number): Promise<BookingWithDetails | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;

    const facility = this.facilities.get(booking.facilityId);
    const timeSlot = this.timeSlots.get(booking.timeSlotId);
    
    return {
      ...booking,
      facilityName: facility?.name || "Unknown",
      date: timeSlot?.date || "",
      startTime: timeSlot?.startTime || "",
      endTime: timeSlot?.endTime || ""
    };
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const newBooking: Booking = { 
      ...booking, 
      id,
      createdAt: new Date(),
      specialRequests: booking.specialRequests || null,
      paymentStatus: booking.paymentStatus || "pending",
      bookingStatus: booking.bookingStatus || "confirmed"
    };
    this.bookings.set(id, newBooking);
    
    // Mark time slot as unavailable
    await this.updateTimeSlotAvailability(booking.timeSlotId, false);
    
    return newBooking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;

    const updated: Booking = { ...booking, bookingStatus: status };
    this.bookings.set(id, updated);
    
    // If booking is cancelled, make the time slot available again
    if (status === "cancelled") {
      await this.updateTimeSlotAvailability(booking.timeSlotId, true);
    }
    
    return updated;
  }

  async getBookingsByEmail(email: string): Promise<BookingWithDetails[]> {
    const bookings = Array.from(this.bookings.values())
      .filter(booking => booking.customerEmail === email)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    return bookings.map(booking => {
      const facility = this.facilities.get(booking.facilityId);
      const timeSlot = this.timeSlots.get(booking.timeSlotId);
      return {
        ...booking,
        facilityName: facility?.name || "Unknown",
        date: timeSlot?.date || "",
        startTime: timeSlot?.startTime || "",
        endTime: timeSlot?.endTime || ""
      };
    });
  }
}

export const storage = new DatabaseStorage();
