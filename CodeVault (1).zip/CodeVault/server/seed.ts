import { db } from "./db";
import { facilities, timeSlots, users } from "@shared/schema";
import bcrypt from "bcryptjs";

export async function seedDatabase() {
  try {
    console.log("🌱 Seeding database...");

    // Check if data already exists
    const existingFacilities = await db.select().from(facilities);
    if (existingFacilities.length > 0) {
      console.log("✅ Database already seeded");
      return;
    }

    // Create admin user
    const hashedPassword = await bcrypt.hash("admin123", 10);
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      role: "admin"
    });

    // Create facilities
    const [facility1] = await db.insert(facilities).values({
      name: "TurfCourt Premium",
      type: "premium",
      description: "Professional-grade artificial turf for premium sports experience",
      pricePerHour: "600.00",
      imageUrl: "https://images.unsplash.com/photo-1459865264687-595d652de67e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=320",
      isActive: true
    }).returning();

    const [facility2] = await db.insert(facilities).values({
      name: "TurfCourt Standard",
      type: "standard",
      description: "High-quality artificial turf for regular sports activities",
      pricePerHour: "600.00",
      imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=320",
      isActive: true
    }).returning();

    // Create time slots for today and next 7 days
    const timeSlotTimes = [
      { start: "06:00", end: "07:00" },
      { start: "07:00", end: "08:00" },
      { start: "08:00", end: "09:00" },
      { start: "09:00", end: "10:00" },
      { start: "10:00", end: "11:00" },
      { start: "11:00", end: "12:00" },
      { start: "12:00", end: "13:00" },
      { start: "13:00", end: "14:00" },
      { start: "14:00", end: "15:00" },
      { start: "15:00", end: "16:00" },
      { start: "16:00", end: "17:00" },
      { start: "17:00", end: "18:00" },
      { start: "18:00", end: "19:00" },
      { start: "19:00", end: "20:00" },
      { start: "20:00", end: "21:00" },
      { start: "21:00", end: "22:00" },
      { start: "22:00", end: "23:00" },
      { start: "23:00", end: "00:00" }
    ];

    const slotsToInsert = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];

      [facility1, facility2].forEach(facility => {
        timeSlotTimes.forEach(time => {
          slotsToInsert.push({
            facilityId: facility.id,
            date: dateStr,
            startTime: time.start,
            endTime: time.end,
            isAvailable: Math.random() > 0.3, // 70% availability
            priceOverride: null
          });
        });
      });
    }

    await db.insert(timeSlots).values(slotsToInsert);

    console.log("✅ Database seeded successfully!");
    console.log(`Created ${slotsToInsert.length} time slots for 2 facilities over 7 days`);
    
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}