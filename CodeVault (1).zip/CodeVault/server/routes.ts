import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import session from "express-session";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { insertBookingSchema, insertFacilitySchema, insertTimeSlotSchema } from "@shared/schema";
import { z } from "zod";

// Store connected WebSocket clients
const wsClients = new Set<WebSocket>();

// Send real-time updates to all connected clients
function broadcastUpdate(event: string, data: any) {
  const message = JSON.stringify({ event, data });
  wsClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// WhatsApp notification function
async function sendWhatsAppNotification(phoneNumber: string, message: string) {
  try {
    // In production, integrate with WhatsApp Business API
    // For now, we'll log the notification
    console.log(`WhatsApp notification to ${phoneNumber}: ${message}`);
    
    // You would integrate with services like:
    // - Twilio WhatsApp API
    // - WhatsApp Business API
    // - Other WhatsApp gateway providers
    
    return { success: true };
  } catch (error) {
    console.error('WhatsApp notification failed:', error);
    return { success: false, error: (error as Error).message };
  }
}

// Admin authentication middleware
const authenticateAdmin = async (req: any, res: any, next: any) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    (req as any).admin = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-session-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
  }));

  // Admin login
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Default admin credentials - you can customize these
      const adminUsername = process.env.ADMIN_USERNAME || "admin";
      const adminPassword = process.env.ADMIN_PASSWORD || "admin123";
      
      if (username !== adminUsername || password !== adminPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const token = jwt.sign(
        { username, role: 'admin' },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: '24h' }
      );
      
      res.json({ token, user: { username, role: 'admin' } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Verify admin token
  app.get("/api/admin/verify", authenticateAdmin, (req: any, res) => {
    res.json({ valid: true, user: req.admin });
  });
  
  // Get all facilities
  app.get("/api/facilities", async (req, res) => {
    try {
      const facilities = await storage.getFacilities();
      res.json(facilities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch facilities" });
    }
  });

  // Get facility by ID
  app.get("/api/facilities/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const facility = await storage.getFacility(id);
      if (!facility) {
        return res.status(404).json({ message: "Facility not found" });
      }
      res.json(facility);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch facility" });
    }
  });

  // Create new facility (admin only)
  app.post("/api/facilities", authenticateAdmin, async (req, res) => {
    try {
      const facilityData = insertFacilitySchema.parse(req.body);
      const facility = await storage.createFacility(facilityData);
      
      // Broadcast real-time update
      broadcastUpdate('facility_created', { facility });
      
      res.status(201).json(facility);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid facility data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create facility" });
    }
  });

  // Update facility (admin only)
  app.patch("/api/facilities/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const facilityData = req.body;
      
      const facility = await storage.updateFacility(id, facilityData);
      if (!facility) {
        return res.status(404).json({ message: "Facility not found" });
      }
      
      // Broadcast real-time update
      broadcastUpdate('facility_updated', { facility });
      
      res.json(facility);
    } catch (error) {
      res.status(500).json({ message: "Failed to update facility" });
    }
  });

  // Get available time slots for a specific date
  app.get("/api/timeslots", async (req, res) => {
    try {
      const date = req.query.date as string;
      if (!date) {
        return res.status(400).json({ message: "Date parameter is required" });
      }
      
      const timeSlots = await storage.getAvailableTimeSlots(date);
      res.json(timeSlots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time slots" });
    }
  });

  // Get time slots for a specific facility and date
  app.get("/api/timeslots/:facilityId/:date", async (req, res) => {
    try {
      const facilityId = parseInt(req.params.facilityId);
      const date = req.params.date;
      
      const timeSlots = await storage.getTimeSlotsByFacilityAndDate(facilityId, date);
      res.json(timeSlots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time slots" });
    }
  });

  // Create new time slot (admin only)
  app.post("/api/timeslots", authenticateAdmin, async (req, res) => {
    try {
      const timeSlotData = insertTimeSlotSchema.parse(req.body);
      const timeSlot = await storage.createTimeSlot(timeSlotData);
      
      // Broadcast real-time update
      broadcastUpdate('timeslot_created', { timeSlot });
      
      res.status(201).json(timeSlot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time slot data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create time slot" });
    }
  });

  // Bulk create time slots for multiple days (admin only)
  app.post("/api/timeslots/bulk", authenticateAdmin, async (req, res) => {
    try {
      const { facilityId, startDate, endDate, timeSlots } = req.body;
      
      const start = new Date(startDate);
      const end = new Date(endDate);
      const createdSlots = [];
      
      for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
        const dateStr = date.toISOString().split('T')[0];
        
        for (const timeSlot of timeSlots) {
          const slotData = {
            facilityId: parseInt(facilityId),
            date: dateStr,
            startTime: timeSlot.startTime,
            endTime: timeSlot.endTime,
            isAvailable: true,
            priceOverride: timeSlot.priceOverride || null,
          };
          
          const createdSlot = await storage.createTimeSlot(slotData);
          createdSlots.push(createdSlot);
        }
      }
      
      // Broadcast real-time update
      broadcastUpdate('timeslots_bulk_created', { count: createdSlots.length });
      
      res.status(201).json({ 
        message: `Created ${createdSlots.length} time slots`,
        slots: createdSlots 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create time slots" });
    }
  });

  // Create new booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      
      // Check if time slot is still available
      const timeSlot = await storage.getTimeSlot(bookingData.timeSlotId);
      if (!timeSlot || !timeSlot.isAvailable) {
        return res.status(400).json({ message: "Time slot is no longer available" });
      }
      
      const booking = await storage.createBooking(bookingData);
      
      // Here you would integrate with payment processor
      // For now, we'll mark it as paid
      await storage.updateBookingStatus(booking.id, "confirmed");
      
      // Get booking details for notification
      const bookingDetails = await storage.getBooking(booking.id);
      
      // Send WhatsApp notification
      if (bookingDetails) {
        const whatsappMessage = `🏆 TurfCourt Booking Confirmed!
        
📍 Field: ${bookingDetails.facilityName}
📅 Date: ${bookingDetails.date}
⏰ Time: ${bookingDetails.startTime} - ${bookingDetails.endTime}
👤 Name: ${bookingDetails.customerName}
💰 Amount: ₹${bookingDetails.totalAmount}
📞 Contact: ${bookingDetails.customerPhone}

Your booking is confirmed! Please arrive 10 minutes early.

For any queries, contact: 9360429797
UPI: 9360429797@ptsbi`;

        await sendWhatsAppNotification(bookingData.customerPhone, whatsappMessage);
      }
      
      // Broadcast real-time update
      broadcastUpdate('booking_created', {
        booking: bookingDetails,
        timeSlotId: bookingData.timeSlotId
      });
      
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  // Get all bookings (admin only)
  app.get("/api/bookings", authenticateAdmin, async (req, res) => {
    try {
      const bookings = await storage.getBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // Get booking by ID
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  // Update booking status
  app.patch("/api/bookings/:id/status", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["confirmed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const booking = await storage.updateBookingStatus(id, status);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Broadcast real-time update
      broadcastUpdate('booking_updated', { booking, timeSlotId: booking.timeSlotId });
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to update booking status" });
    }
  });

  // Get bookings by email
  app.get("/api/bookings/email/:email", async (req, res) => {
    try {
      const email = req.params.email;
      const bookings = await storage.getBookingsByEmail(email);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // Send booking confirmation email
  app.post("/api/bookings/:id/send-confirmation", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Here you would integrate with email service (e.g., SendGrid, Nodemailer)
      // Using environment variables for API keys
      const emailApiKey = process.env.EMAIL_API_KEY || process.env.SENDGRID_API_KEY || "demo_key";
      
      // For demo purposes, we'll just return success
      // In production, you'd send an actual email
      console.log(`Sending confirmation email to ${booking.customerEmail} for booking ${id}`);
      
      res.json({ message: "Confirmation email sent successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to send confirmation email" });
    }
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    wsClients.add(ws);
    
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      wsClients.delete(ws);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      wsClients.delete(ws);
    });
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({ event: 'connected', data: { message: 'Connected to TurfCourt real-time updates' } }));
  });
  
  return httpServer;
}
