import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileText, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { BookingWithDetails } from "@shared/schema";

interface ExportDataProps {
  bookings: BookingWithDetails[];
}

export default function ExportData({ bookings }: ExportDataProps) {
  const { toast } = useToast();

  const exportToCSV = () => {
    const headers = [
      'Booking ID', 'Customer Name', 'Customer Email', 'Customer Phone',
      'Facility', 'Date', 'Start Time', 'End Time', 'Players',
      'Amount', 'Status', 'Payment Status', 'Created At', 'Special Requests'
    ];

    const csvData = bookings.map(booking => [
      booking.id,
      booking.customerName,
      booking.customerEmail,
      booking.customerPhone,
      booking.facilityName,
      booking.date,
      booking.startTime,
      booking.endTime,
      booking.numberOfPlayers,
      booking.totalAmount,
      booking.bookingStatus,
      booking.paymentStatus,
      booking.createdAt ? new Date(booking.createdAt).toLocaleString() : '',
      booking.specialRequests || ''
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `turfcourt-bookings-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "Bookings data has been exported to CSV",
    });
  };

  const generateReport = () => {
    const totalBookings = bookings.length;
    const confirmedBookings = bookings.filter(b => b.bookingStatus === 'confirmed').length;
    const totalRevenue = bookings
      .filter(b => b.bookingStatus === 'confirmed')
      .reduce((sum, booking) => sum + parseFloat(booking.totalAmount), 0);

    const reportData = {
      generatedAt: new Date().toLocaleString(),
      totalBookings,
      confirmedBookings,
      cancelledBookings: bookings.filter(b => b.bookingStatus === 'cancelled').length,
      totalRevenue: totalRevenue.toFixed(2),
      conversionRate: totalBookings > 0 ? ((confirmedBookings / totalBookings) * 100).toFixed(1) : '0',
    };

    const reportContent = `
TurfCourt Booking Report
Generated: ${reportData.generatedAt}

Summary:
- Total Bookings: ${reportData.totalBookings}
- Confirmed Bookings: ${reportData.confirmedBookings}
- Cancelled Bookings: ${reportData.cancelledBookings}
- Total Revenue: ₹${reportData.totalRevenue}
- Conversion Rate: ${reportData.conversionRate}%

Recent Bookings:
${bookings.slice(0, 10).map(booking => 
  `${booking.customerName} - ${booking.facilityName} - ${booking.date} ${booking.startTime}-${booking.endTime} - ₹${booking.totalAmount} (${booking.bookingStatus})`
).join('\n')}
    `;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `turfcourt-report-${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Report Generated",
      description: "Business report has been downloaded",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Export & Reports</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button
          onClick={exportToCSV}
          className="w-full flex items-center gap-2"
          variant="outline"
        >
          <Download className="h-4 w-4" />
          Export to CSV
        </Button>
        
        <Button
          onClick={generateReport}
          className="w-full flex items-center gap-2"
          variant="outline"
        >
          <FileText className="h-4 w-4" />
          Generate Report
        </Button>
        
        <Button
          onClick={() => {
            const subject = encodeURIComponent('TurfCourt Booking Summary');
            const body = encodeURIComponent(`Hi,

Here's your TurfCourt booking summary:
- Total Bookings: ${bookings.length}
- Confirmed: ${bookings.filter(b => b.bookingStatus === 'confirmed').length}
- Revenue: ₹${bookings.filter(b => b.bookingStatus === 'confirmed').reduce((sum, b) => sum + parseFloat(b.totalAmount), 0).toFixed(2)}

Best regards,
TurfCourt Admin`);
            window.open(`mailto:devakumaran2003@gmail.com?subject=${subject}&body=${body}`);
          }}
          className="w-full flex items-center gap-2"
          variant="outline"
        >
          <Mail className="h-4 w-4" />
          Email Summary
        </Button>
      </CardContent>
    </Card>
  );
}