import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Facility, TimeSlotWithDetails } from "@shared/schema";

interface TimeSlotGridProps {
  facilities: Facility[];
  selectedDate: string;
  onTimeSlotSelect: (timeSlot: TimeSlotWithDetails, facility: Facility) => void;
}

export default function TimeSlotGrid({ facilities, selectedDate, onTimeSlotSelect }: TimeSlotGridProps) {
  const { data: timeSlots, isLoading } = useQuery({
    queryKey: ['/api/timeslots', selectedDate],
    queryFn: async () => {
      const response = await fetch(`/api/timeslots?date=${selectedDate}`);
      if (!response.ok) throw new Error('Failed to fetch time slots');
      return response.json() as Promise<TimeSlotWithDetails[]>;
    },
    enabled: !!selectedDate,
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {facilities.map((facility) => (
          <Card key={facility.id} className="overflow-hidden">
            <CardHeader className="bg-green-600 text-white p-4">
              <Skeleton className="h-6 w-3/4 bg-green-400" />
              <Skeleton className="h-4 w-1/2 bg-green-400" />
            </CardHeader>
            <div className="h-40 bg-gray-200">
              <Skeleton className="w-full h-full" />
            </div>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const facilityTimeSlots = facilities.map(facility => ({
    facility,
    slots: timeSlots?.filter(slot => slot.facilityId === facility.id) || []
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {facilityTimeSlots.map(({ facility, slots }) => (
        <Card key={facility.id} className="overflow-hidden shadow-lg border">
          <CardHeader className="bg-green-600 text-white p-4">
            <h3 className="text-xl font-bold">{facility.name}</h3>
            <p className="text-green-100">{facility.description}</p>
          </CardHeader>
          
          <div 
            className="h-40 bg-cover bg-center"
            style={{
              backgroundImage: `url(${facility.imageUrl || 'https://images.unsplash.com/photo-1459865264687-595d652de67e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=320'})`
            }}
          />
          
          <CardContent className="p-6">
            <div className="grid grid-cols-2 gap-3">
              {slots.length > 0 ? (
                slots.map((slot) => (
                  <Button
                    key={slot.id}
                    variant={slot.isAvailable ? "outline" : "secondary"}
                    className={`p-3 h-auto flex flex-col items-center justify-center ${
                      slot.isAvailable 
                        ? "sports-bg-light border-green-600 sports-text-green hover:bg-green-600 hover:text-white" 
                        : "bg-gray-100 border-gray-300 text-gray-400 cursor-not-allowed"
                    }`}
                    disabled={!slot.isAvailable}
                    onClick={() => slot.isAvailable && onTimeSlotSelect(slot, facility)}
                  >
                    <div className="text-sm font-medium">
                      {slot.startTime} - {slot.endTime}
                    </div>
                    <div className="text-xs">
                      {slot.isAvailable ? `₹${slot.pricePerHour}/hour` : "Booked"}
                    </div>
                  </Button>
                ))
              ) : (
                <div className="col-span-2 text-center text-gray-500 py-8">
                  No time slots available for this date
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
