import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Facility, TimeSlotWithDetails } from "@shared/schema";
import { z } from "zod";

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  timeSlot: TimeSlotWithDetails | null;
  facility: Facility | null;
}

const bookingFormSchema = insertBookingSchema.extend({
  customerEmail: z.string().email("Please enter a valid email address"),
  customerPhone: z.string().min(10, "Phone number must be at least 10 digits"),
  numberOfPlayers: z.number().min(1, "At least 1 player required").max(50, "Maximum 50 players allowed"),
});

type BookingFormData = z.infer<typeof bookingFormSchema>;

export default function BookingModal({ isOpen, onClose, timeSlot, facility }: BookingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      numberOfPlayers: 1,
      specialRequests: "",
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (bookingData: BookingFormData) => {
      const response = await apiRequest('POST', '/api/bookings', bookingData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Booking Confirmed!",
        description: "Redirecting to payment...",
      });
      
      // Generate UPI payment link
      const upiId = "9360429797@ptsbi";
      const amount = timeSlot?.pricePerHour || "600.00";
      const bookingId = data.id;
      const customerName = form.getValues("customerName");
      const facilityName = facility?.name || "TurfCourt";
      
      const upiLink = `upi://pay?pa=${upiId}&pn=TurfCourt&am=${amount}&cu=INR&tn=Booking%20${bookingId}%20-%20${facilityName}%20-%20${customerName}`;
      
      // Try to open UPI payment link, with fallback
      try {
        window.open(upiLink, '_blank');
        
        // Show additional toast with payment details as fallback
        setTimeout(() => {
          toast({
            title: "Payment Details",
            description: `UPI ID: ${upiId} | Amount: ₹${amount} | Booking ID: ${bookingId}`,
            duration: 8000,
          });
        }, 2000);
        
      } catch (error) {
        // Fallback: show payment details
        toast({
          title: "Payment Required",
          description: `Please pay ₹${amount} to UPI ID: ${upiId}`,
          duration: 8000,
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/timeslots'] });
      onClose();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message || "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormData) => {
    if (!timeSlot || !facility) return;
    
    const bookingData = {
      ...data,
      facilityId: facility.id,
      timeSlotId: timeSlot.id,
      totalAmount: timeSlot.pricePerHour,
    };
    
    createBookingMutation.mutate(bookingData);
  };

  if (!timeSlot || !facility) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold sports-text-dark">
            Complete Your Booking
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Booking Summary */}
          <div className="sports-bg-light rounded-lg p-4">
            <h4 className="font-semibold sports-text-dark mb-2">Booking Summary</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Field:</span>
                <span className="font-medium">{facility.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span className="font-medium">{timeSlot.date}</span>
              </div>
              <div className="flex justify-between">
                <span>Time:</span>
                <span className="font-medium">{timeSlot.startTime} - {timeSlot.endTime}</span>
              </div>
              <div className="flex justify-between font-semibold">
                <span>Total:</span>
                <span className="sports-text-green">₹{timeSlot.pricePerHour}</span>
              </div>
            </div>
          </div>
          
          {/* Payment Information */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 mb-2">Payment Information</h4>
            <div className="space-y-1 text-sm text-blue-700">
              <p><strong>UPI ID:</strong> 9360429797@ptsbi</p>
              <p><strong>Contact:</strong> 9360429797</p>
              <p className="text-xs text-blue-600">After booking, you'll be redirected to payment</p>
            </div>
          </div>
          
          {/* Customer Information Form */}
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your full name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Enter your email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerPhone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input type="tel" placeholder="Enter your phone number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="numberOfPlayers"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Players</FormLabel>
                    <FormControl>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select number of players" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1-5 players</SelectItem>
                          <SelectItem value="6">6-10 players</SelectItem>
                          <SelectItem value="11">11-15 players</SelectItem>
                          <SelectItem value="16">16-20 players</SelectItem>
                          <SelectItem value="21">21+ players</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="specialRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Requests (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any special requirements or notes"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-3 pt-4">
                <Button
                  type="submit"
                  className="w-full sports-btn-primary"
                  disabled={createBookingMutation.isPending}
                >
                  {createBookingMutation.isPending 
                    ? "Processing..." 
                    : `Book & Pay Now - ₹${timeSlot.pricePerHour}`
                  }
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={onClose}
                  disabled={createBookingMutation.isPending}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
