import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter } from "lucide-react";
import type { BookingWithDetails } from "@shared/schema";

interface SearchFilterProps {
  bookings: BookingWithDetails[];
  onFilteredBookings: (filtered: BookingWithDetails[]) => void;
}

export default function SearchFilter({ bookings, onFilteredBookings }: SearchFilterProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");

  const applyFilters = (search: string, status: string, date: string) => {
    let filtered = [...bookings];

    // Search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(booking =>
        booking.customerName.toLowerCase().includes(searchLower) ||
        booking.customerEmail.toLowerCase().includes(searchLower) ||
        booking.customerPhone.includes(search) ||
        booking.facilityName.toLowerCase().includes(searchLower)
      );
    }

    // Status filter
    if (status !== "all") {
      filtered = filtered.filter(booking => booking.bookingStatus === status);
    }

    // Date filter
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    
    if (date !== "all") {
      switch (date) {
        case "today":
          filtered = filtered.filter(booking => booking.date === todayStr);
          break;
        case "week":
          const weekAgo = new Date(today);
          weekAgo.setDate(today.getDate() - 7);
          const weekAgoStr = weekAgo.toISOString().split('T')[0];
          filtered = filtered.filter(booking => booking.date >= weekAgoStr && booking.date <= todayStr);
          break;
        case "month":
          const monthAgo = new Date(today);
          monthAgo.setMonth(today.getMonth() - 1);
          const monthAgoStr = monthAgo.toISOString().split('T')[0];
          filtered = filtered.filter(booking => booking.date >= monthAgoStr);
          break;
      }
    }

    onFilteredBookings(filtered);
  };

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    applyFilters(value, statusFilter, dateFilter);
  };

  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    applyFilters(searchTerm, value, dateFilter);
  };

  const handleDateChange = (value: string) => {
    setDateFilter(value);
    applyFilters(searchTerm, statusFilter, value);
  };

  return (
    <Card className="mb-6">
      <CardContent className="p-6">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex-1 min-w-[250px]">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name, email, phone, or facility..."
                value={searchTerm}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-500" />
            
            <Select value={statusFilter} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={dateFilter} onValueChange={handleDateChange}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Dates</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="mt-3 text-sm text-gray-600">
          Showing {bookings.length} booking{bookings.length !== 1 ? 's' : ''}
        </div>
      </CardContent>
    </Card>
  );
}