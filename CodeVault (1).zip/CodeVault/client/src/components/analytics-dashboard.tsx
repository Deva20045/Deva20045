import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Calendar, Clock, Users } from "lucide-react";
import type { BookingWithDetails } from "@shared/schema";

interface AnalyticsDashboardProps {
  bookings: BookingWithDetails[];
}

export default function AnalyticsDashboard({ bookings }: AnalyticsDashboardProps) {
  // Calculate analytics
  const totalRevenue = bookings
    .filter(b => b.bookingStatus === 'confirmed')
    .reduce((sum, booking) => sum + parseFloat(booking.totalAmount), 0);

  const totalBookings = bookings.length;
  const confirmedBookings = bookings.filter(b => b.bookingStatus === 'confirmed').length;
  const cancelledBookings = bookings.filter(b => b.bookingStatus === 'cancelled').length;
  
  const conversionRate = totalBookings > 0 ? (confirmedBookings / totalBookings) * 100 : 0;

  // Peak hours analysis
  const hourlyBookings = bookings
    .filter(b => b.bookingStatus === 'confirmed')
    .reduce((acc, booking) => {
      const hour = booking.startTime.split(':')[0];
      acc[hour] = (acc[hour] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

  const peakHour = Object.entries(hourlyBookings)
    .sort(([,a], [,b]) => b - a)[0]?.[0] || 'N/A';

  // Recent bookings trend (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date.toISOString().split('T')[0];
  });

  const recentBookings = last7Days.map(date => 
    bookings.filter(b => b.date === date && b.bookingStatus === 'confirmed').length
  );

  const avgBookingsPerDay = recentBookings.reduce((sum, count) => sum + count, 0) / 7;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold sports-text-green">₹{totalRevenue.toFixed(2)}</div>
          <p className="text-xs text-muted-foreground">
            +{((totalRevenue / (totalBookings || 1)) * 100).toFixed(1)}% avg per booking
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
          <Calendar className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{conversionRate.toFixed(1)}%</div>
          <p className="text-xs text-muted-foreground">
            {confirmedBookings} confirmed / {totalBookings} total
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Peak Hour</CardTitle>
          <Clock className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{peakHour}:00</div>
          <p className="text-xs text-muted-foreground">
            {hourlyBookings[peakHour] || 0} bookings
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Daily Average</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{avgBookingsPerDay.toFixed(1)}</div>
          <p className="text-xs text-muted-foreground">
            bookings per day (7-day avg)
          </p>
        </CardContent>
      </Card>
    </div>
  );
}