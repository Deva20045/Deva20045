import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import type { BookingWithDetails } from "@shared/schema";

interface BookingCalendarProps {
  onDateSelect: (date: Date | undefined) => void;
  selectedDate: Date | undefined;
}

export default function BookingCalendar({ onDateSelect, selectedDate }: BookingCalendarProps) {
  const { data: bookings } = useQuery({
    queryKey: ['/api/bookings'],
    queryFn: async () => {
      const token = localStorage.getItem('admin_token');
      const response = await fetch('/api/bookings', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch bookings');
      return response.json() as Promise<BookingWithDetails[]>;
    },
  });

  // Get booking counts for each date
  const getBookingCountForDate = (date: Date) => {
    if (!bookings) return 0;
    const dateString = date.toISOString().split('T')[0];
    return bookings.filter(booking => 
      booking.date === dateString && booking.bookingStatus === 'confirmed'
    ).length;
  };

  const modifiers = {
    hasBookings: (date: Date) => getBookingCountForDate(date) > 0,
  };

  const modifiersStyles = {
    hasBookings: {
      backgroundColor: 'var(--sports-green)',
      color: 'white',
      borderRadius: '4px',
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Booking Calendar
          <Badge variant="outline" className="sports-text-green">
            Live Updates
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={onDateSelect}
          modifiers={modifiers}
          modifiersStyles={modifiersStyles}
          className="rounded-md border"
        />
        <div className="mt-4 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded"></div>
            <span>Dates with bookings</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}