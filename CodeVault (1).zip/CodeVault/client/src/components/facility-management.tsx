import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFacilitySchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, MapPin } from "lucide-react";
import type { Facility, InsertFacility } from "@shared/schema";
import { z } from "zod";

const facilityFormSchema = insertFacilitySchema.extend({
  pricePerHour: z.string().transform(val => parseFloat(val).toFixed(2)),
});

type FacilityFormData = z.infer<typeof facilityFormSchema>;

export default function FacilityManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddingFacility, setIsAddingFacility] = useState(false);
  const [editingFacility, setEditingFacility] = useState<Facility | null>(null);

  const { data: facilities, isLoading } = useQuery({
    queryKey: ['/api/facilities'],
    queryFn: async () => {
      const response = await fetch('/api/facilities');
      if (!response.ok) throw new Error('Failed to fetch facilities');
      return response.json() as Promise<Facility[]>;
    },
  });

  const form = useForm<FacilityFormData>({
    resolver: zodResolver(facilityFormSchema),
    defaultValues: {
      name: "",
      type: "standard",
      description: "",
      pricePerHour: "600.00",
      imageUrl: "",
      isActive: true,
    },
  });

  const createFacilityMutation = useMutation({
    mutationFn: async (facilityData: FacilityFormData) => {
      const token = localStorage.getItem('admin_token');
      const response = await fetch('/api/facilities', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(facilityData),
      });
      if (!response.ok) throw new Error('Failed to create facility');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Facility Created",
        description: "New facility has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/facilities'] });
      setIsAddingFacility(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create facility",
        variant: "destructive",
      });
    },
  });

  const updateFacilityMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<FacilityFormData> }) => {
      const token = localStorage.getItem('admin_token');
      const response = await fetch(`/api/facilities/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update facility');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Facility Updated",
        description: "Facility has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/facilities'] });
      setEditingFacility(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update facility",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FacilityFormData) => {
    if (editingFacility) {
      updateFacilityMutation.mutate({ id: editingFacility.id, data });
    } else {
      createFacilityMutation.mutate(data);
    }
  };

  const handleEdit = (facility: Facility) => {
    setEditingFacility(facility);
    setIsAddingFacility(true);
    form.reset({
      name: facility.name,
      type: facility.type,
      description: facility.description,
      pricePerHour: facility.pricePerHour,
      imageUrl: facility.imageUrl || "",
      isActive: facility.isActive || true,
    });
  };

  const handleCancel = () => {
    setIsAddingFacility(false);
    setEditingFacility(null);
    form.reset();
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Facility Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">Loading facilities...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Facility Management
          <Button
            onClick={() => setIsAddingFacility(true)}
            className="sports-btn-primary flex items-center gap-2"
            disabled={isAddingFacility}
          >
            <Plus className="h-4 w-4" />
            Add Facility
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isAddingFacility && (
          <div className="mb-6 p-4 border rounded-lg bg-gray-50">
            <h3 className="font-semibold mb-4">
              {editingFacility ? 'Edit Facility' : 'Add New Facility'}
            </h3>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Facility Name</FormLabel>
                        <FormControl>
                          <Input placeholder="TurfCourt Premium" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="standard">Standard</SelectItem>
                              <SelectItem value="premium">Premium</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Professional-grade artificial turf for premium sports experience"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="pricePerHour"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price per Hour (₹)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01"
                            placeholder="600.00" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Image URL (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://example.com/image.jpg" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    type="submit"
                    className="sports-btn-primary"
                    disabled={createFacilityMutation.isPending || updateFacilityMutation.isPending}
                  >
                    {createFacilityMutation.isPending || updateFacilityMutation.isPending
                      ? "Saving..." 
                      : editingFacility ? "Update Facility" : "Add Facility"
                    }
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {facilities?.map((facility) => (
            <Card key={facility.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold sports-text-dark">{facility.name}</h4>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(facility)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <p className="text-sm text-gray-600 mb-2">{facility.description}</p>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium sports-text-green">₹{facility.pricePerHour}/hr</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    facility.type === 'premium' 
                      ? 'bg-yellow-100 text-yellow-800' 
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {facility.type}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}