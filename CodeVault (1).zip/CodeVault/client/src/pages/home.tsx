import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import Navbar from "@/components/navbar";
import TimeSlotGrid from "@/components/time-slot-grid";
import BookingModal from "@/components/booking-modal";
import { Calendar, Phone, Mail, MapPin } from "lucide-react";
import type { Facility, TimeSlotWithDetails } from "@shared/schema";

export default function Home() {
  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<TimeSlotWithDetails | null>(null);
  const [selectedFacility, setSelectedFacility] = useState<Facility | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const { data: facilities, isLoading } = useQuery({
    queryKey: ['/api/facilities'],
    queryFn: async () => {
      const response = await fetch('/api/facilities');
      if (!response.ok) throw new Error('Failed to fetch facilities');
      return response.json() as Promise<Facility[]>;
    },
  });

  const handleTimeSlotSelect = (timeSlot: TimeSlotWithDetails, facility: Facility) => {
    setSelectedTimeSlot(timeSlot);
    setSelectedFacility(facility);
    setIsBookingModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsBookingModalOpen(false);
    setSelectedTimeSlot(null);
    setSelectedFacility(null);
  };

  const getDateOptions = () => {
    const options = [];
    const today = new Date();
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      const label = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : 
        date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
      options.push({ value: dateStr, label });
    }
    
    return options;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gray-900 text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')`
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Book Premium TurfCourt
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              Professional-grade artificial turf facilities available 6 AM to midnight. Book your slot in seconds.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button className="sports-btn-primary text-lg px-8 py-4">
                Book Now
              </Button>
              <Button variant="outline" className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-gray-900">
                View Facilities
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Interface */}
      <section id="booking" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold sports-text-dark mb-4">
              Select Your Time Slot
            </h2>
            <p className="text-gray-600 text-lg">
              Choose from our available turf fields and time slots
            </p>
          </div>

          {/* Date Selection */}
          <div className="sports-bg-light rounded-xl p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
              <div className="flex items-center space-x-2">
                <Calendar className="sports-text-green" size={20} />
                <span className="font-medium">Select Date:</span>
              </div>
              <div className="flex flex-wrap gap-2 justify-center">
                {getDateOptions().map((option) => (
                  <Button
                    key={option.value}
                    variant={selectedDate === option.value ? "default" : "outline"}
                    className={selectedDate === option.value ? "sports-btn-primary" : "sports-btn-secondary"}
                    onClick={() => setSelectedDate(option.value)}
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Time Slots Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {[1, 2].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="bg-green-600 p-4">
                    <Skeleton className="h-6 w-3/4 bg-green-400" />
                    <Skeleton className="h-4 w-1/2 bg-green-400 mt-2" />
                  </div>
                  <Skeleton className="h-40 w-full" />
                  <CardContent className="p-6">
                    <div className="grid grid-cols-2 gap-3">
                      {Array.from({ length: 6 }).map((_, j) => (
                        <Skeleton key={j} className="h-16 w-full" />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : facilities && facilities.length > 0 ? (
            <TimeSlotGrid
              facilities={facilities}
              selectedDate={selectedDate}
              onTimeSlotSelect={handleTimeSlotSelect}
            />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-600">No facilities available at the moment.</p>
            </div>
          )}
        </div>
      </section>

      {/* Facilities Showcase */}
      <section className="py-16 sports-bg-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold sports-text-dark mb-4">
              World-Class Facilities
            </h2>
            <p className="text-gray-600 text-lg">
              Experience the difference with our premium sports infrastructure
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="overflow-hidden">
              <div 
                className="h-48 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400')`
                }}
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold sports-text-dark mb-2">FIFA-Approved Turf</h3>
                <p className="text-gray-600">Professional-grade artificial turf meeting international standards for optimal play.</p>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div 
                className="h-48 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400')`
                }}
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold sports-text-dark mb-2">LED Floodlights</h3>
                <p className="text-gray-600">State-of-the-art LED lighting system for perfect visibility during evening games.</p>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div 
                className="h-48 bg-cover bg-center"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1556741533-6e6a62bd8b49?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400')`
                }}
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold sports-text-dark mb-2">Smart Booking</h3>
                <p className="text-gray-600">Advanced booking system with real-time availability and instant confirmations.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold sports-text-dark mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-gray-600 text-lg">
              No hidden fees, no membership required
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="sports-bg-light text-center p-8">
              <h3 className="text-2xl font-bold sports-text-dark mb-4">Standard Field</h3>
              <div className="text-4xl font-bold sports-text-green mb-2">₹600</div>
              <div className="text-gray-600 mb-6">per hour</div>
              <ul className="text-left text-gray-600 space-y-2 mb-8">
                <li className="flex items-center">✓ High-quality artificial turf</li>
                <li className="flex items-center">✓ LED lighting</li>
                <li className="flex items-center">✓ Basic changing rooms</li>
                <li className="flex items-center">✓ Free parking</li>
              </ul>
              <Button className="w-full sports-btn-primary">
                Book Now
              </Button>
            </Card>

            <Card className="bg-green-600 text-white text-center p-8 transform scale-105">
              <div className="bg-white text-green-600 px-3 py-1 rounded-full text-sm font-semibold mb-4 inline-block">
                MOST POPULAR
              </div>
              <h3 className="text-2xl font-bold mb-4">Premium Field</h3>
              <div className="text-4xl font-bold mb-2">₹600</div>
              <div className="text-green-100 mb-6">per hour</div>
              <ul className="text-left text-green-100 space-y-2 mb-8">
                <li className="flex items-center">✓ FIFA-approved turf</li>
                <li className="flex items-center">✓ Premium LED lighting</li>
                <li className="flex items-center">✓ Luxury changing rooms</li>
                <li className="flex items-center">✓ Equipment storage</li>
                <li className="flex items-center">✓ Free refreshments</li>
              </ul>
              <Button className="w-full bg-white text-green-600 hover:bg-gray-100">
                Book Now
              </Button>
            </Card>

            <Card className="sports-bg-light text-center p-8">
              <h3 className="text-2xl font-bold sports-text-dark mb-4">Tournament</h3>
              <div className="text-4xl font-bold sports-text-green mb-2">₹10,800</div>
              <div className="text-gray-600 mb-6">per day</div>
              <ul className="text-left text-gray-600 space-y-2 mb-8">
                <li className="flex items-center">✓ Full day access</li>
                <li className="flex items-center">✓ Multiple fields</li>
                <li className="flex items-center">✓ Event coordination</li>
                <li className="flex items-center">✓ Catering options</li>
              </ul>
              <Button className="w-full sports-btn-primary">
                Contact Us
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <span className="text-2xl mr-3">⚽</span>
                <span className="text-xl font-bold">TurfCourt</span>
              </div>
              <p className="text-gray-400">
                Professional sports turf booking made simple. Book your game today! Contact: 9360429797
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-green-400">Book Now</a></li>
                <li><a href="#" className="hover:text-green-400">Facilities</a></li>
                <li><a href="#" className="hover:text-green-400">Pricing</a></li>
                <li><a href="#" className="hover:text-green-400">About Us</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <Phone className="mr-2 h-4 w-4" />
                  +1 (555) 123-4567
                </li>
                <li className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  info@turfbookpro.com
                </li>
                <li className="flex items-center">
                  <MapPin className="mr-2 h-4 w-4" />
                  123 Sports Complex Dr
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-green-400">Facebook</a>
                <a href="#" className="text-gray-400 hover:text-green-400">Twitter</a>
                <a href="#" className="text-gray-400 hover:text-green-400">Instagram</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 TurfCourt. All rights reserved. | UPI: 9360429797@ptsbi | Contact: 9360429797</p>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={handleCloseModal}
        timeSlot={selectedTimeSlot}
        facility={selectedFacility}
      />
    </div>
  );
}
