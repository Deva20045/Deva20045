import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/navbar";
import BookingCalendar from "@/components/booking-calendar";
import AnalyticsDashboard from "@/components/analytics-dashboard";
import ExportData from "@/components/export-data";
import SearchFilter from "@/components/search-filter";
import FacilityManagement from "@/components/facility-management";
import { Calendar, Clock, User, Mail, Phone, Users, X, Check, LogOut } from "lucide-react";
import type { BookingWithDetails } from "@shared/schema";

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [filteredBookings, setFilteredBookings] = useState<BookingWithDetails[]>([]);

  // Check admin authentication
  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      toast({
        title: "Access Denied",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      setLocation('/admin/login');
    }
  }, [toast, setLocation]);

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_user');
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out",
    });
    setLocation('/admin/login');
  };
  
  const { data: bookings, isLoading } = useQuery({
    queryKey: ['/api/bookings'],
    queryFn: async () => {
      const token = localStorage.getItem('admin_token');
      const response = await fetch('/api/bookings', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('admin_token');
          localStorage.removeItem('admin_user');
          setLocation('/admin/login');
          throw new Error('Session expired');
        }
        throw new Error('Failed to fetch bookings');
      }
      return response.json() as Promise<BookingWithDetails[]>;
    },
  });

  const updateBookingMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const token = localStorage.getItem('admin_token');
      const response = await fetch(`/api/bookings/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('admin_token');
          localStorage.removeItem('admin_user');
          setLocation('/admin/login');
          throw new Error('Session expired');
        }
        throw new Error('Failed to update booking');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Updated",
        description: "Booking status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/timeslots'] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update booking status.",
        variant: "destructive",
      });
    },
  });

  // Update filtered bookings when bookings data changes
  useEffect(() => {
    if (bookings) {
      setFilteredBookings(bookings);
    }
  }, [bookings]);

  const handleStatusUpdate = (bookingId: number, newStatus: string) => {
    updateBookingMutation.mutate({ id: bookingId, status: newStatus });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            <Skeleton className="h-8 w-48" />
            <div className="grid gap-6">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold sports-text-dark mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage bookings and facility operations</p>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        {/* Analytics Dashboard */}
        {bookings && <AnalyticsDashboard bookings={bookings} />}

        {/* Calendar and Export Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <BookingCalendar
              selectedDate={selectedDate}
              onDateSelect={setSelectedDate}
            />
          </div>
          <div>
            {bookings && <ExportData bookings={bookings} />}
          </div>
        </div>

        {/* Facility Management */}
        <FacilityManagement />

        {/* Search and Filter */}
        {bookings && (
          <SearchFilter
            bookings={bookings}
            onFilteredBookings={setFilteredBookings}
          />
        )}

        {/* Bookings List */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold sports-text-dark">
            {selectedDate 
              ? `Bookings for ${selectedDate.toLocaleDateString()}` 
              : 'All Bookings'
            }
          </h2>
          
          {filteredBookings && filteredBookings.length > 0 ? (
            <div className="grid gap-6">
              {filteredBookings.map((booking) => (
                <Card key={booking.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg sports-text-dark">
                          {booking.facilityName}
                        </CardTitle>
                        <p className="text-sm text-gray-600">
                          Booking #{booking.id} • {booking.createdAt ? new Date(booking.createdAt).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Badge className={getStatusColor(booking.bookingStatus)}>
                          {booking.bookingStatus}
                        </Badge>
                        <Badge className={getPaymentStatusColor(booking.paymentStatus)}>
                          {booking.paymentStatus}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.date}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.startTime} - {booking.endTime}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.customerName}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.customerEmail}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Phone className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.customerPhone}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span className="text-sm">{booking.numberOfPlayers} players</span>
                      </div>
                    </div>
                    
                    {booking.specialRequests && (
                      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-700">
                          <strong>Special Requests:</strong> {booking.specialRequests}
                        </p>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold sports-text-green">
                        ₹{booking.totalAmount}
                      </span>
                      
                      {booking.bookingStatus === 'confirmed' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleStatusUpdate(booking.id, 'cancelled')}
                          disabled={updateBookingMutation.isPending}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          {updateBookingMutation.isPending ? 'Updating...' : 'Cancel Booking'}
                        </Button>
                      )}
                      
                      {booking.bookingStatus === 'cancelled' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleStatusUpdate(booking.id, 'confirmed')}
                          disabled={updateBookingMutation.isPending}
                          className="sports-text-green hover:text-green-700 hover:bg-green-50"
                        >
                          {updateBookingMutation.isPending ? 'Updating...' : 'Restore Booking'}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Bookings Yet</h3>
                <p className="text-gray-500">Bookings will appear here when customers make reservations.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
